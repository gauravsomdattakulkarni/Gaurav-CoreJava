package com.telusko.SPRINGJDBCExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringjdbcExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringjdbcExampleApplication.class, args);
	}

}
